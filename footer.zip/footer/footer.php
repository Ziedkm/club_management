<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CampusESTG Footer Example</title>
    <!-- Link to your CSS file -->
    <link rel="stylesheet" href="style.css">
    <!-- Link to Font Awesome for social icons -->
    <link rel="stylesheet" href="footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

    <!-- ... Your main page content above ... -->

    <footer class="site-footer">
        <div class="footer-content container">
            <div class="footer-section about">
                <h2 class="logo-text"><span class="logo-campus">club</span>nest</h2>
                <p>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Numquam quidem quaerat vero id reiciendis, officia fugit culpa, maiores atque est sit, molestias beatae quo architecto nobis harum nemo suscipit sequi?
                </p>
            </div>

            <div class="footer-section links">
                <h2>SUIVEZ-NOUS</h2>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Services</a></li>
                    <li><a href="#">clubs</a></li>
                    <li><a href="#">why clubnest </a></li>
                    <li><a href="#">Team</a></li>
                    <li><a href="#">Contact Us</a></li>
                </ul>
            </div>

            <div class="footer-section contact">
                <h2>CONTACT US</h2>
                <p>
                    Sousse Higher Institute of Management, Sousse, Tunisia<br>
                    TUNISIE<br>
                    <strong>Tél:</strong> 216123456789<br>
                    <strong>Fax:</strong> 216737373737<br>
                    <strong>Email:</strong> ISGS@CONTACT.COM
                </p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-google-plus-g"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>

            <div class="footer-section stay-connected">
                <h2>RESTEZ BRANCHÉS !</h2>
                <p>
                    Restez connecté aux dernières
                    nouvelles et informations de
                    <span class="highlight">club</span><span class="highlight-white">nest</span>.
                </p>
            </div>
        </div>

        <div class="footer-bottom">
            © Copyright <span class="highlight-white">clubnest</span>. All Rights Reserved<br>
            Designed by Zied & MejdEddine & Yassmine & Rayen & Azer 
        </div>
    </footer>

    <!-- ... Potential JS scripts below ... -->
    <!-- <script src="script.js"></script> -->

</body>
</html>